/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productcalculation;

/**
 *
 * @author Student
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

public class ProductCalculation {

    private double price;

    public ProductCalculation(double price) {
        this.price = price;
    }

    public double GetVat() {
        return price * 0.15;
    }

    public double GetCommission() {
        return price * 0.05;
    }

    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}
