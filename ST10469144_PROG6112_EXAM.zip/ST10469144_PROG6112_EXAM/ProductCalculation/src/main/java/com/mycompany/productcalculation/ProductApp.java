/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productcalculation;
import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
/**
 *
 * @author Student
 */
public class ProductApp extends JFrame {

    private JTextField txtCustomer;
    private JTextField txtPrice;
    private JComboBox<String> cmbProduct;

    public ProductApp() {

        setTitle("Product App");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));

        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        fileMenu.add(exitItem);
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        txtCustomer = new JTextField();

        cmbProduct = new JComboBox<>(new String[]{
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phunket"
        });

        txtPrice = new JTextField();

        JButton btnProcess = new JButton("PROCESS");

        add(new JLabel("Customer Name:"));
        add(txtCustomer);

        add(new JLabel("Select Product:"));
        add(cmbProduct);

        add(new JLabel("Enter Price:"));
        add(txtPrice);

        add(new JLabel(""));
        add(btnProcess);

        btnProcess.addActionListener(e -> processSale());

        processItem.addActionListener(e -> processSale());

        clearItem.addActionListener(e -> clearForm());

        exitItem.addActionListener(e -> System.exit(0));

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void processSale() {

        try {

            String customer = txtCustomer.getText();
            String product = (String) cmbProduct.getSelectedItem();
            double price = Double.parseDouble(txtPrice.getText());

            if (customer.trim().isEmpty() || price <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Please enter valid information.");
                return;
            }

            ProductCalculation calculation =
                    new ProductCalculation(price);

            double vat = calculation.GetVat();
            double commission = calculation.GetCommission();
            double total = calculation.GetTotal();

            String message =
                    "Customer Name: " + customer +
                    "\nProduct: " + product +
                    "\nVAT: R " + String.format("%.2f", vat) +
                    "\nCOMMISSION: R " + String.format("%.2f", commission) +
                    "\nTOTAL: R " + String.format("%.2f", total);

            JOptionPane.showMessageDialog(this, message);

            saveData(customer, product, vat, commission, total);

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(this,
                    "Please enter a valid product price.");
        }
    }

    private void saveData(String customer, String product,
                          double vat, double commission, double total) {

        try (PrintWriter writer =
                new PrintWriter(new FileWriter("data.txt", true))) {

            writer.println("******** DATA LOG ********");
            writer.println("Customer Name: " + customer);
            writer.println("Product: " + product);
            writer.println("VAT: R " + vat);
            writer.println("COMMISSION: R " + commission);
            writer.println("TOTAL: R " + total);
            writer.println("**************************");

        } catch (IOException ex) {

            JOptionPane.showMessageDialog(this,
                    "Error saving data.");
        }
    }

    private void clearForm() {

        txtCustomer.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> new ProductApp());
    }
}
    

