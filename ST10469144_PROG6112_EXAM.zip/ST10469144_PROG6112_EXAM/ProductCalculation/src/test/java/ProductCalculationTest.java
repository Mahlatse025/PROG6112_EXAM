/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import com.mycompany.productcalculation.ProductCalculation;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductCalculationTest {

    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {

        ProductCalculation calculation =
                new ProductCalculation(3500);

        assertEquals(525.0, calculation.GetVat(), 0.01);
    }
}