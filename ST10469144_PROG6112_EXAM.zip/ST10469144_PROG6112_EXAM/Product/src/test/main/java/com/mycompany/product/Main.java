/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.product;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class Main {


    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phunket"
        };

        int[][] sales = new int[3][3];

        for (int i = 0; i < products.length; i++) {

            for (int j = 0; j < 3; j++) {

                System.out.print("Enter number of sales for month "
                        + (j + 1) + " for " + products[i] + ": ");

                sales[i][j] = input.nextInt();
            }
        }

        Product product = new Product(products, sales);

        PrintProduct report = new PrintProduct();

        report.printReport(product);

        input.close();
    }
}
